#from sklearn.datasets import fetch_20newsgroups

# chose a couple categories out of the 20 files
#categories = ["alt.atheism","sci.med"]
#newsgroups_train = fetch_20newsgroups(subset='train', shuffle=True, categories = categories)
#newsgroups_test = fetch_20newsgroups(subset='test', shuffle=True, categories = categories)
